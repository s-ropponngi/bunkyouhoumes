<?php

/** Template Name: 会社情報
 */
?>

<!DOCTYPE html>
<html lang="ja">

<head prefix=”og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# website: http://ogp.me/ns/website#”>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta name="X-UA-Compatible" content="ie=edge" />
  <meta name="format-detection" content="telephone=no" />
  <!-- meta情報 -->
  <title>CodeUps</title>
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <!-- ogp -->
  <meta property="og:title" content="" />
  <meta property="og:type" content="" />
  <meta property="og:url" content="" />
  <meta property="og:image" content="" />
  <meta property="og:site_name" content="" />
  <meta property="og:description" content="" />
  <!-- ファビコン -->
  <link rel="”icon”" href="" />
  <!-- google font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Murecho:wght@400;700&family=Noto+Sans+JP:wght@400;700&display=swap" rel="stylesheet">
  <!-- FontAwesome -->

  <?php wp_head() ?>

  <!-- css -->
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css">
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.1/animate.min.css" /> -->

  <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/styles.css">

  <!--クローラー -->
  <meta name="robots" content="noindex">
</head>

<body>

<?php $args = array(
    'numberposts' => 4, //表示する記事の数
    'post_type' => 'estate' //投稿タイプ名
    // 条件を追加する場合はここに追記
  );
  $customPosts = get_posts($args);
  if ($customPosts) : foreach ($customPosts as $post) : setup_postdata($post);
  ?>
      <div class="area-employ__item">
        <h3 class="area-employ__ttl">
          <?php if (!empty(SCF::get('top_comment'))) : ?>
            <div><?php echo SCF::get('top_comment'); ?></div>
          <?php endif; ?>
        </h3>
        <div>
          <?php echo SCF::get('name'); ?>
        </div>
        <div>
          <?php echo SCF::get('pref'); ?>
        </div>
        <?php
        $image = SCF::get('image');
        echo wp_get_attachment_image($image, 'medium');
        ?>
        <a href="<?php echo SCF::get('link') ?>" target="_blank">物件詳細</a>
      </div>

    <?php endforeach; ?>
  <?php else : //記事が無い場合 
  ?>
    <p>物件はありません</p>
  <?php endif;
  wp_reset_postdata(); //クエリのリセット 
  ?>
 

  <ul class="info-list">
    <?php
    $args = array(
      // 'category_name' => 'information', //カテゴリースラッグを指定。複数の場合はカンマ区切り
      'posts_per_page' => 10 //取得記事件数
    );
    $posts = get_posts($args);
    foreach ($posts as $post) :
      setup_postdata($post);
      $category = get_the_category();
      $cat_name = $category[0]->cat_name;
      $cat_slug = $category[0]->slug;

    ?>
      <li class="info-list__item">
        <a href="<?php the_permalink(); ?>" class="info-list__link">
          <?php if (has_post_thumbnail()) : ?>
            <div class="info-list__img">
              <?php the_post_thumbnail('medium'); ?>
            </div>
          <?php endif; ?>
          <div class="info-list__body">
            <p class="cat cat--<?php echo $cat_slug; ?>"><?php echo $cat_name; ?></p>
            <p class="ttl"><?php the_title(); ?></p>
            <p class="date"><?php the_time('Y年n月j日') ?></p>
          </div>
        </a>
      </li>
    <?php
    endforeach;
    wp_reset_postdata();
    ?>
  </ul>



  <!-- <div class="c-info-card">

    <div class="c-info-card__btn">
      <a href="" class="c-btn">物件詳細</a>
    </div>

  </div>
  <div class="p-btn">
    <a href="" class="c-btn">PUSH</a>
  </div>
  <div class="p-news">
    <div class="p-news__title">
      <h3 class="c-section-title">お知らせ</h3>
    </div>
    <div class="p-news__brock">
      <a href="" class="c-news">テキストはいります</a>
      <a href="" class="c-news">テキストはいります</a>
      <a href="" class="c-news">テキストはいります</a>
      <a href="" class="c-news">テキストはいります</a>
      <a href="" class="c-news">テキストはいります</a>
    </div>
    <div class="p-news__btn">
      <a href="" class="c-btn">お知らせ一覧</a>
    </div>
  </div>

  <div class="p-work">
    <div class="p-work__title">
      <h3 class="c-section-title">事業内容</h3>
    </div>
    <div class="p-work__btn">
      <img src="" alt="">
      <a href="" class="c-work"></a>
    </div>
    <div class="p-work__btn">
      <img src="" alt="">
      <a href="" class="c-work"></a>
    </div>
    <div class="p-work__btn">
      <img src="" alt="">
      <a href="" class="c-work"></a>
    </div>
    <div class="p-work__btn">
      <img src="" alt="">
      <a href="" class="c-work"></a>
    </div>
  </div> -->


  <!-- ブログ -->
  <section class="c-blog">
    <div class="c-blog-title">タイトル</div>
    <div class="c-blog-in">2022年1月1日</div>
    <div class="c-blog-text">
      テキストテキストテキストテキストテキストテキステキストテキストトテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト
    </div>
  </section>



  <!-- 物件スライダー -->
  <section class="p-info-slider l-container">
    <div class="p-info-slider__in">

      <a href="">
        <div class="p-info-slider__item">
          <figure class="image">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/top/1470757063.jpg" alt="">
          </figure>
          <p class="title">
            事務所
          </p>
        </div>
      </a>

      <a href="">
        <div class="p-info-slider__item">
          <figure class="image">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/top/1470757063.jpg" alt="">
          </figure>
          <p class="title">賃貸</p>
        </div>
      </a>
      <a href="">
        <div class="p-info-slider__item">
          <figure class="image">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/top/1470757063.jpg" alt="">
          </figure>
          <p class="title">駐車場</p>
        </div>
      </a>
      <a href="">
        <div class="p-info-slider__item">
          <figure class="image">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/top/1470757063.jpg" alt="">
          </figure>
          <p class="title">売買</p>
        </div>
      </a>

    </div>
  </section>


  <!-- 会社概要フェードイン -->
  <div class="p-about-vision">
    <div class="p-about-vision__title">経営理念</div>
    <div class="p-about-vision__text">
      快適で安全安心な住環境をすべての入居者の皆様に将来にわたって心地良い住まいを提供してまいります。
    </div>

    <p class="fadein txt01">１．自然と調和した住環境の提供・整備</p>
    <p class="fadein txt02">２．安全安心な暮らしの提供</p>
    <p class="fadein txt03">３．幸福度の追求</p>

  </div>


  <!-- 会社概要スライダー -->
  <!-- <div class="p-about-vision slide-in-right">
    <div class="p-about-vision__title">経営理念</div>
    <div class="p-about-vision__text">
      快適で安全安心な住環境をすべての入居者の皆様に将来にわたって心地良い住まいを提供してまいります。
    </div>
    <div class="p-about-vision__text">
      １．自然と調和した住環境の提供・整備
    </div>
    <div class="p-about-vision__text">
      ２．安全安心な暮らしの提供
    </div>
    <div class="p-about-vision__text">
      ３．幸福度の追求
    </div>
  </div> -->

  <!-- アクセススライダー -->
  <section class="p-access-slider">
    <div class="p-access-slide__in">
      <div class="p-access-slide__item">
        <figure>
          <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/office-1.jpg" alt="">
        </figure>
      </div>
      <div class="p-access-slide__item">
        <figure>
          <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/office-2.jpeg" alt="">
        </figure>
      </div>
      <div class="p-access-slide__item">
        <figure>
          <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/office-3.jpeg" alt="">
        </figure>
      </div>
      <div class="p-access-slide__item">
        <figure>
          <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/office-4.jpeg" alt="">
        </figure>
      </div>

      <!-- ここから下 ダミー -->
      <div class="p-access-slide__item">
        <figure>
          <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/office-4.jpeg" alt="">
        </figure>
      </div>
      <div class="p-access-slide__item">
        <figure>
          <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/office-4.jpeg" alt="">
        </figure>
      </div>
      <div class="p-access-slide__item">
        <figure>
          <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/office-4.jpeg" alt="">
        </figure>
      </div>
    </div>
  </section>

  <iframe src="" frameborder="0"></iframe>


  <!-- map -->
  <section class="p-access-map l-container">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12850.093444977465!2d139.0842572!3d36.3723225!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x29196d55625b0e4c!2z5paH5Lqs44Ob44O844Og44K6TExD!5e0!3m2!1sja!2sjp!4v1657368792514!5m2!1sja!2sjp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </section>


  <!-- アクセス案内 -->
  <section class="p-access-guide">
    <div class="p-access-guide__item">
      <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/n-guide.jpg" alt="">
      <div class="p-access-guide__title">南方面からお越しのお客様。
      </div>
      <div class="p-access-guide__text">
        ベイシアマート前橋六供店様を通り過ぎ、約200mほど進んでいただきますと当事務所がございます。青い建物(自然酵母パンブランジェトム・ソーヤーb-tom」様)の隣です。
      </div>
    </div>
    <div class="p-access-guide__item">
      <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/n-guide.jpg" alt="">
      <div class="p-access-guide__title">北方面からお越しのお客様。
      </div>
      <div class="p-access-guide__text">
        群馬県生涯学習センター様から約600mほど進んでいただきますと右側に当事務所がございます。
      </div>
    </div>
  </section>


  <!-- 吹き出し -->
  <div class="c-balloon-wrapper">
    <section class="c-balloon">
      ご来店の折は事前予約をお願い致します。<br>
      定休日、営業時間外でも事前にご連絡いただければ、対応可能です。
    </section>
    <div class="icon">
      <img src="<?php echo get_template_directory_uri(); ?>/images/Bunkyo-Holmes/access/character-icon.png" alt="">
    </div>
  </div>





  <!-- JavaScript -->
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-inview@1.1.2/jquery.inview.min.js"></script>

</body>

</html>